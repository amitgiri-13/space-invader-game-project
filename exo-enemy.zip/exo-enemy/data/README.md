# space-invader-game-project
This is my first game project using pygame in python. I build this game in the course of learning about basics of how pygame works. Freecodecamp.org provided me major learning materials during this project. Here is the link to the video of freecodecamp.org : https://www.youtube.com/watch?v=FfWpgLFMI7w
